def realizar_operacion(operacion, operando1, operando2):
    """Realiza una operación matemática.

    Args:
        operacion (str): Operación a realizar (SUM, RES, MUL, DIV, POT).
        operando1 (float): Primer operando.
        operando2 (float): Segundo operando.

    Returns:
        float: Resultado de la operación.
    """

    if operacion == "SUM":
        return operando1 + operando2
    elif operacion == "RES":
        return operando1 - operando2
    # ... y así sucesivamente para las demás operaciones
    else:
        raise ValueError("Operación no válida")

def leer_csv(archivo):
    """Lee un archivo CSV y devuelve una lista de diccionarios.

    Args:
        archivo (str): Nombre del archivo CSV.

    Returns:
        list: Lista de diccionarios, donde cada diccionario representa una fila del CSV.
    """

    import csv  # Importamos csv dentro de la función para evitar conflictos de módulos

    with open(archivo, 'r') as csvfile:
        reader = csv.DictReader(csvfile)
        data = list(reader)
    return data

def actualizar_csv(archivo, datos_actualizados):
    """Actualiza un archivo CSV con nuevos datos.

    Args:
        archivo (str): Nombre del archivo CSV.
        datos_actualizados (list): Lista de diccionarios con los datos actualizados.
    """

    import csv  # Importamos csv dentro de la función para evitar conflictos de módulos

    with open(archivo, 'w', newline='') as csvfile:
        fieldnames = datos_actualizados[0].keys()
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(datos_actualizados)