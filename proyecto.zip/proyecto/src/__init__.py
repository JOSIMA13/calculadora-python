# src/__init__.py
from .calculadora import realizar_operacion
from .lector_archivos import leer_archivo
from .graficador import generar_grafico