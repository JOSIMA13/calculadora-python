from src.calculadora import realizar_operacion

def test_suma():
    assert realizar_operacion("SUM", 2, 3) == 5

def test_resta():
    assert realizar_operacion("RES", 5, 2) == 3

# ... y así sucesivamente para las demás operaciones